from controller import Robot
import asyncio
import websockets
import json
import threading

TIME_STEP = 32
MAX_VELOCITY = 10.0

# 初始化 Webots robot 物件
robot = Robot()

# 取得馬達裝置
wheel1 = robot.getDevice("wheel1")  # Front-right
wheel2 = robot.getDevice("wheel2")  # Front-left
wheel3 = robot.getDevice("wheel3")  # Rear-right
wheel4 = robot.getDevice("wheel4")  # Rear-left

for wheel in [wheel1, wheel2, wheel3, wheel4]:
    wheel.setPosition(float('inf'))
    wheel.setVelocity(0.0)

# 控制函數
def set_wheel_velocity(v1, v2, v3, v4):
    wheel1.setVelocity(v1)
    wheel2.setVelocity(v2)
    wheel3.setVelocity(v3)
    wheel4.setVelocity(v4)

# WebSocket handler
async def websocket_handler(websocket, path):
    print("✅ WebSocket client connected.")
    try:
        async for message in websocket:
            print(f"📩 Received: {message}")
            data = json.loads(message)
            direction = data.get("direction", "").upper()

            if direction == "UP":
                set_wheel_velocity(MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY, MAX_VELOCITY)
            elif direction == "DOWN":
                set_wheel_velocity(-MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY, -MAX_VELOCITY)
            elif direction == "LEFT":
                set_wheel_velocity(-MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY)
            elif direction == "RIGHT":
                set_wheel_velocity(MAX_VELOCITY, -MAX_VELOCITY, MAX_VELOCITY, -MAX_VELOCITY)
            elif direction == "STOP":
                set_wheel_velocity(0, 0, 0, 0)
    except websockets.exceptions.ConnectionClosed:
        print("⚠️ Client disconnected.")

# 執行 WebSocket server
def run_ws_server():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    start_server = websockets.serve(websocket_handler, "0.0.0.0", 8081)
    print("🚀 WebSocket server listening on port 8081")
    loop.run_until_complete(start_server)
    loop.run_forever()

# 背景啟動 WebSocket server
ws_thread = threading.Thread(target=run_ws_server, daemon=True)
ws_thread.start()

# Webots 主迴圈
while robot.step(TIME_STEP) != -1:
    pass
